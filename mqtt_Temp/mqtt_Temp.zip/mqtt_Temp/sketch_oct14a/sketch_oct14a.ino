#include <WiFi.h>            // or <ESP8266WiFi.h> for NodeMCU
#include <PubSubClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>

const char* ssid = "RevSinMax";
const char* password = "alrightokay2";
const char* mqtt_server = "172.20.10.5";  // Your PC IP running Mosquitto

WiFiClient espClient;
PubSubClient client(espClient);

#define ONE_WIRE_BUS 5  // GPIO5
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("Temp_Sensor_Client")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  setup_wifi();
  client.setServer(mqtt_server, 1883);
  sensors.begin();
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  sensors.requestTemperatures(); // Send the command to get temperatures
  float tempC = sensors.getTempCByIndex(0); // first sensor
  char msg[10];
  dtostrf(tempC, 4, 2, msg); // convert float to string with 2 decimals

  client.publish("sensor/temp", msg);
  Serial.print("Temperature: ");
  Serial.println(msg);

  delay(1000); // Publish every second
}
