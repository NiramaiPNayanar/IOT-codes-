#include <WiFi.h>            // or <ESP8266WiFi.h> for NodeMCU
#include <PubSubClient.h>

const char* ssid = "RevSinMax";
const char* password = "alrightokay2";
const char* mqtt_server = "172.20.10.5";  // Your PC's IP (where Mosquitto runs)

WiFiClient espClient;
PubSubClient client(espClient);

const int irPin = 5; // Example: GPIO5 (D1 on NodeMCU)

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    if (client.connect("IR_Sensor_Client")) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      delay(5000);
    }
  }
}

void setup() {
  pinMode(irPin, INPUT);
  Serial.begin(115200);
  setup_wifi();
  client.setServer(mqtt_server, 1883);
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  int irValue = digitalRead(irPin);
  char msg[10];
  sprintf(msg, "%d", irValue);
  client.publish("sensor/ir", msg);

  Serial.print("IR Value: ");
  Serial.println(irValue);

  delay(1000); // publish every second
}
